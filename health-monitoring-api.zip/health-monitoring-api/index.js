const express = require('express');
const app = express();
const port = 3001; 

const healthData = [
    { name: 'Heart Rate', value: '72 bpm' },
    { name: 'Blood Pressure', value: '120/80 mmHg' },
];

const aiAnalysis = [
    { id: 1, description: 'Risk of Hypertension: Low' },
    { id: 2, description: 'Recommended Exercise: 30 minutes of walking daily' },
];

app.get('/api/healthdata', (req, res) => {
    res.json(healthData);
});

app.get('/api/analysis', (req, res) => {
    res.json(aiAnalysis);
});

app.listen(port, () => {
    console.log(`API is running at http://localhost:${port}`);
});