// Dashboard.js
import React, { useState } from 'react';
import HealthData from './HealthData';
import AIAnalysis from './AIAnalysis';
import Login from './Login'; // Import the Login component
import SignUp from './SignUp'; // Import the SignUp component
import '../styles/App.css';
import healthImage from '../images/health-monitoring.png'; 

const Dashboard = () => {
    const [isLoginOpen, setIsLoginOpen] = useState(false);
    const [isSignUpOpen, setIsSignUpOpen] = useState(false);

    const openLoginModal = () => {
        setIsLoginOpen(true);
        setIsSignUpOpen(false); // Close sign-up modal if open
    };

    const openSignUpModal = () => {
        setIsSignUpOpen(true);
        setIsLoginOpen(false); // Close login modal if open
    };

    const closeModal = () => {
        setIsLoginOpen(false);
        setIsSignUpOpen(false);
    };

    return (
        <div className="container">
            <center><h1>Smart Health Monitoring System</h1></center>
            <center><img src={healthImage} alt="Health Monitoring" /></center>
            <center>
                <button onClick={openLoginModal}>Login</button>
                <button onClick={openSignUpModal}>Sign Up</button>
            </center>
            {isLoginOpen && <Login onClose={closeModal} onSwitchToSignUp={openSignUpModal} />}
            {isSignUpOpen && <SignUp onClose={closeModal} />}
            <center><HealthData /></center>
            <center><AIAnalysis /></center>
        </div>
    );
};

export default Dashboard;