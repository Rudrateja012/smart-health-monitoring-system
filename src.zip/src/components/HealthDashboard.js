import React, { useEffect, useState } from 'react';
import { fetchHealthData, fetchAIAnalysis } from './services/api';

const HealthDashboard = () => {
    const [healthData, setHealthData] = useState([]);
    const [aiAnalysis, setAIAnalysis] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);

    useEffect(() => {
        const loadData = async () => {
            try {
                const healthDataResponse = await fetchHealthData();
                setHealthData(healthDataResponse);

                const aiAnalysisResponse = await fetchAIAnalysis();
                setAIAnalysis(aiAnalysisResponse);
            } catch (error) {
                console.error(error); 
                setError('Failed to fetch data. Please try again later.');
            } finally {
                setLoading(false);
            }
        };

        loadData();
    }, []);

    if (loading) return <div>Loading...</div>;
    if (error) return <div>{error}</div>;

    return (
        <div>
            <h1>Health Data</h1>
            <ul>
                {healthData.map((item) => (
                    <li key={item.id}>{item.name}: {item.value}</li> 
                ))}
            </ul>

            <h1>AI Analysis</h1>
            <ul>
                {aiAnalysis.map((item) => (
                    <li key={item.id}>{item.description}</li>
                ))}
            </ul>
        </div>
    );
};

export default HealthDashboard;