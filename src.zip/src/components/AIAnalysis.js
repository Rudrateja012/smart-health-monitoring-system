
import React, { useEffect, useState } from 'react';
import { fetchAIAnalysis } from '../services/api';

const AIAnalysis = () => {
    const [analysisResults, setAnalysisResults] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);

    useEffect(() => {
        const getAnalysis = async () => {
            try {
                const results = await fetchAIAnalysis();
                setAnalysisResults(results);
            } catch (err) {
                setError("Failed to fetch health data....");
            } finally {
                setLoading(false);
            }
        };
        getAnalysis();
    }, []);

    if (loading) return <p>Loading...</p>;
    if (error) return <p>{error}</p>;

    return (
        <div>
            <h2>AI Analysis</h2>
            <ul>
                {analysisResults.map(result => (
                    <li key={result.id}>{result.description}</li>
                ))}
            </ul>
        </div>
    );
};

export default AIAnalysis;