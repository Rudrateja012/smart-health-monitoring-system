
import React, { useEffect, useState } from 'react';
import { fetchHealthData } from '../services/api';

const HealthData = () => {
    const [data, setData] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);

    useEffect(() => {
        const getData = async () => {
            try {
                const result = await fetchHealthData();
                setData(result);
            } catch (err) {
                setError(" Failed to fetch health data....");
            } finally {
                setLoading(false);
            }
        };
        getData();
    }, []);

    if (loading) return <p>Loading...</p>;
    if (error) return <p>{error}</p>;

    return (
        <div>
            <h2>Health Data</h2>
            <ul>
                {data.map((item, index) => (
                    <li key={index}>{item.name}: {item.value}</li>
                ))}
            </ul>
        </div>
    );
};

export default HealthData;