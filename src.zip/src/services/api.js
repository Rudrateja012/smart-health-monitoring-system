import axios from 'axios';

const API_BASE_URL = 'http://localhost:3001';

// Function to fetch health data from the API
export const fetchHealthData = async () => {
    try {
        const response = await axios.get(`${API_BASE_URL}/api/healthdata`); // Ensure the correct endpoint is used
        return response.data; // Return the health data
    } catch (error) {
        console.error('Error fetching health data:', error); // Log the error for debugging
        throw error; // Rethrow the error to be handled by the calling function
    }
};

// Function to fetch AI analysis from the API
export const fetchAIAnalysis = async () => {
    try {
        const response = await axios.get(`${API_BASE_URL}/api/analysis`); // Ensure the correct endpoint is used
        return response.data; // Return the AI analysis data
    } catch (error) {
        console.error('Error fetching AI analysis:', error); // Log the error for debugging
        throw error; // Rethrow the error to be handled by the calling function
    }
};